# EdgeOS Databento Proxy v3

## Files

- `server.cjs`
- `package.json`
- `railway.json`
- `Procfile`

## Required Railway environment variable

```env
DATABENTO_API_KEY=your_databento_key_here
```

Optional variables are already defaulted in `server.cjs`:

```env
DATABENTO_DATASET=GLBX.MDP3
DATABENTO_SCHEMA=trades
DATABENTO_SYMBOLS=NQ.c.0,ES.c.0,MNQ.c.0,MES.c.0
STALE_THRESHOLD_SECONDS=30
```

Do not set `PORT` manually on Railway. Railway injects it.

## GitHub deploy steps

1. Create a new GitHub repo, for example `edgeos-databento-proxy`.
2. Upload these files into the repo root, not inside an extra folder.
3. In Railway, create a new service from that GitHub repo.
4. Add `DATABENTO_API_KEY` in Railway Variables.
5. Deploy.
6. Open your Railway domain and verify the endpoints below.

## Verification endpoints

Replace `<RAILWAY_URL>` with your Railway domain.

```text
<RAILWAY_URL>/health
<RAILWAY_URL>/snapshot
<RAILWAY_URL>/bars/status
<RAILWAY_URL>/bars/1m?symbol=NQ&n=5
<RAILWAY_URL>/bars/5m?symbol=NQ&n=3
```

Expected signs of success:

- `/health` shows `connected: true`, `auth_success: true`, and `connection_state: "streaming"`.
- `/snapshot` shows live NQ/ES price with low `age_seconds`.
- `/bars/status` shows `websocket_connected: true`, cached bars, and `historical_fallback_recommended: false` once healthy.
- `/bars/1m?symbol=NQ&n=5` returns completed 1m bars and a `forming_bar`.
- `/bars/5m?symbol=NQ&n=3` returns completed 5m bars and a `forming_bar`.

## Source verification

`server.cjs` line count from this package: 896

SHA-256:

```text
306d7e85f911b3729ea8ef4b500b56be7312c18afe630b066eb275a4994e23c7
```

## Troubleshooting

### WebSocket not connected

Check Railway logs. Confirm `DATABENTO_API_KEY` is set and valid.

### Authentication failed

Your Databento key may be wrong or your subscription may not include `GLBX.MDP3` live trades.

### No ticks received

During active CME hours, wait 1–2 minutes. If still no ticks, check Railway logs for Databento auth or socket errors.

### bars_1m = 0

Wait for historical seed and first live ticks. If it stays zero during market hours, the stream may not be mapping instruments correctly.

### Scanner still using historical_rest

Make sure Base44 `LIVE_DATA_PROXY_URL` points to the Railway URL with no trailing slash. Then run proxy diagnostics again and confirm `/bars/status` is healthy.
