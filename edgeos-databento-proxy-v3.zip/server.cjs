/* eslint-disable no-undef */
"use strict";

/**
 * EdgeOS Databento Live Proxy v3
 *
 * v3 additions over v2:
 *   - Rolling OHLCV bar builder: every trade tick is aggregated into 1m and 5m bars in-memory.
 *   - /bars/1m  — returns last N completed 1m bars + current forming bar per symbol
 *   - /bars/5m  — same for 5m
 *   - /bars/status — cache health, counts, last bar timestamps, gap detection
 *   - Cold-start seed: on startup, fetches historical bars from Databento REST once to pre-fill
 *     the rolling cache so scanners don't wait for 75 minutes of live ticks before having data.
 *   - Gap detection: after reconnect, fetches missing bars from REST to fill any gap.
 *   - bar_source tag on every bar: "proxy_live" | "historical_seed" | "historical_gap_fill"
 */

require("dotenv").config();
const net     = require("net");
const crypto  = require("crypto");
const express = require("express");
const cors    = require("cors");
const https   = require("https");

// ── Config ─────────────────────────────────────────────────────────────────────
const API_KEY           = process.env.DATABENTO_API_KEY;
const PORT              = parseInt(process.env.PORT || "3001", 10);
const DATASET           = process.env.DATABENTO_DATASET   || "GLBX.MDP3";
const SCHEMA            = process.env.DATABENTO_SCHEMA    || "trades";
const RAW_SYMBOLS       = process.env.DATABENTO_SYMBOLS   || "NQ.c.0,ES.c.0,MNQ.c.0,MES.c.0";
const STALE_THRESHOLD_S = parseInt(process.env.STALE_THRESHOLD_SECONDS || "30", 10);

// Rolling bar retention
const MAX_1M_BARS  = 300;  // 5 hours of 1m bars
const MAX_5M_BARS  = 2016; // 7 days of 5m bars
const MAX_15M_BARS = 480;  // 5 days of 15m bars

const SYMBOL_ALIASES = {
  "NQ.c.0": "NQ", "ES.c.0": "ES", "MNQ.c.0": "MNQ", "MES.c.0": "MES",
};
const FRIENDLY_TO_RAW = Object.fromEntries(Object.entries(SYMBOL_ALIASES).map(([r, f]) => [f, r]));

function toFriendly(raw) {
  if (!raw) return null;
  const s = raw.trim();
  if (SYMBOL_ALIASES[s]) return SYMBOL_ALIASES[s];
  const m = s.match(/^(NQ|ES|MNQ|MES)/);
  return m ? m[1] : null;
}

function gatewayHost(dataset) {
  return dataset.toLowerCase().replace(/\./g, "-") + ".lsg.databento.com";
}

const GATEWAY_HOST = gatewayHost(DATASET);
const GATEWAY_PORT = 13000;

// ── In-memory caches ───────────────────────────────────────────────────────────
const priceCache      = {};   // sym → latest tick
const sessionOHLCV    = {};   // sym → { open, high, low, vwap, tickCount }
const instrumentIdMap = {};
const pendingTrades   = {};

// ── Rolling OHLCV bar caches ───────────────────────────────────────────────────
// bars1m[sym] = array of completed 1m bars, newest last
// bars5m[sym] = array of completed 5m bars, newest last
// forming1m[sym] = currently forming 1m bar (not yet complete)
// forming5m[sym] = currently forming 5m bar

const bars1m    = {};  // sym → Bar[]
const bars5m    = {};  // sym → Bar[]
const bars15m   = {};  // sym → Bar[]
const forming1m = {};  // sym → FormingBar | null
const forming5m = {};  // sym → FormingBar | null
const forming15m= {};  // sym → FormingBar | null

// Seed state
const seedState = {};  // sym → { seeded: bool, seedTime: number, seedCount: int }
const gapFillLog = []; // recent gap fill events

function barBucketMs(tsMs, intervalMs) {
  return Math.floor(tsMs / intervalMs) * intervalMs;
}

function newBar(openPrice, tsMs, intervalMs, source) {
  return {
    open:   openPrice,
    high:   openPrice,
    low:    openPrice,
    close:  openPrice,
    volume: 0,
    ts:     barBucketMs(tsMs, intervalMs),
    ts_iso: new Date(barBucketMs(tsMs, intervalMs)).toISOString(),
    bar_source: source || "proxy_live",
  };
}

function tickIntoBar(bar, price, size) {
  if (price > bar.high) bar.high = price;
  if (price < bar.low)  bar.low  = price;
  bar.close  = price;
  bar.volume += size || 1;
}

function pushCompletedBar(arr, bar, maxLen) {
  arr.push({ ...bar });
  if (arr.length > maxLen) arr.splice(0, arr.length - maxLen);
}

/**
 * Process a trade tick into the rolling bar caches.
 * Called for every decoded trade record.
 */
function updateRollingBars(friendly, price, tsEventMs, size) {
  const now = tsEventMs || Date.now();

  for (const [intervalMs, formingMap, completedArr, maxLen] of [
    [60_000,  forming1m,  bars1m,  MAX_1M_BARS],
    [300_000, forming5m,  bars5m,  MAX_5M_BARS],
    [900_000, forming15m, bars15m, MAX_15M_BARS],
  ]) {
    const bucket = barBucketMs(now, intervalMs);

    if (!formingMap[friendly]) {
      // No forming bar yet — start one
      formingMap[friendly] = newBar(price, now, intervalMs, "proxy_live");
      formingMap[friendly].volume = size || 1;
    } else if (formingMap[friendly].ts !== bucket) {
      // New time bucket — complete the previous bar and start new one
      if (!completedArr[friendly]) completedArr[friendly] = [];
      pushCompletedBar(completedArr[friendly], formingMap[friendly], maxLen);
      formingMap[friendly] = newBar(price, now, intervalMs, "proxy_live");
      formingMap[friendly].volume = size || 1;
    } else {
      // Same bucket — update forming bar
      tickIntoBar(formingMap[friendly], price, size);
    }
  }
}

// ── Historical bar seeder (REST API) ──────────────────────────────────────────
function fetchHistoricalBars(rawSym, schema, startIso, endIso) {
  return new Promise((resolve) => {
    if (!API_KEY) { resolve([]); return; }
    const body = new URLSearchParams({
      dataset: DATASET, symbols: rawSym, stype_in: "continuous",
      schema, start: startIso, end: endIso, encoding: "json",
    }).toString();

    const opts = {
      hostname: "hist.databento.com",
      path: "/v0/timeseries.get_range",
      method: "POST",
      headers: {
        "Authorization": "Basic " + Buffer.from(API_KEY + ":").toString("base64"),
        "Content-Type": "application/x-www-form-urlencoded",
        "Content-Length": Buffer.byteLength(body),
      },
      timeout: 20000,
    };

    let raw = "";
    const req = https.request(opts, (res) => {
      res.on("data", d => { raw += d; });
      res.on("end", () => {
        if (res.statusCode !== 200) { resolve([]); return; }
        const bars = [];
        for (const line of raw.trim().split("\n").filter(Boolean)) {
          try {
            const r = JSON.parse(line);
            if (r.close == null) continue;
            bars.push({
              open:   parseFloat(r.open)  / 1e9,
              high:   parseFloat(r.high)  / 1e9,
              low:    parseFloat(r.low)   / 1e9,
              close:  parseFloat(r.close) / 1e9,
              volume: parseInt(r.volume)  || 0,
              ts:     r.ts_event ? Math.floor(Number(BigInt(r.ts_event) / 1_000_000n)) : 0,
              ts_iso: r.ts_event ? new Date(Math.floor(Number(BigInt(r.ts_event) / 1_000_000n))).toISOString() : null,
              bar_source: "historical_seed",
            });
          } catch {}
        }
        resolve(bars);
      });
    });
    req.on("error", () => resolve([]));
    req.on("timeout", () => { req.destroy(); resolve([]); });
    req.write(body);
    req.end();
  });
}

async function seedSymbol(friendly) {
  const rawSym = FRIENDLY_TO_RAW[friendly];
  if (!rawSym || !API_KEY) return;
  if (seedState[friendly]?.seeded) return;

  safeLog(`Seeding historical bars for ${friendly}…`);
  const now  = Date.now();
  const end  = new Date(now - 16 * 60_000); // 16 min behind (API enforces 15 min offset)
  const start1m  = new Date(end.getTime()  - MAX_1M_BARS  * 60_000);
  const start5m  = new Date(end.getTime()  - MAX_5M_BARS  * 5 * 60_000);
  const start15m = new Date(end.getTime()  - MAX_15M_BARS * 15 * 60_000);

  const [h1m, h5m, h15m] = await Promise.all([
    fetchHistoricalBars(rawSym, "ohlcv-1m",  start1m.toISOString(),  end.toISOString()),
    fetchHistoricalBars(rawSym, "ohlcv-5m",  start5m.toISOString(),  end.toISOString()),
    fetchHistoricalBars(rawSym, "ohlcv-15m", start15m.toISOString(), end.toISOString()),
  ]);

  // Seed each interval — mark as historical_seed so scanners know origin
  if (h1m.length > 0) {
    bars1m[friendly] = h1m.slice(-MAX_1M_BARS);
    safeLog(`  ${friendly} 1m seed: ${h1m.length} bars`);
  }
  if (h5m.length > 0) {
    bars5m[friendly] = h5m.slice(-MAX_5M_BARS);
    safeLog(`  ${friendly} 5m seed: ${h5m.length} bars`);
  }
  if (h15m.length > 0) {
    bars15m[friendly] = h15m.slice(-MAX_15M_BARS);
    safeLog(`  ${friendly} 15m seed: ${h15m.length} bars`);
  }

  seedState[friendly] = { seeded: true, seedTime: Date.now(), seedCount1m: h1m.length, seedCount5m: h5m.length };
  safeLog(`Seed complete for ${friendly}`);
}

// After reconnect, fill gaps between last cached bar and now
async function gapFillSymbol(friendly) {
  const rawSym = FRIENDLY_TO_RAW[friendly];
  if (!rawSym || !API_KEY) return;

  const lastBar1m = bars1m[friendly]?.at(-1);
  if (!lastBar1m || !lastBar1m.ts) return;

  const gapStartMs = lastBar1m.ts + 60_000;
  const gapEndMs   = Date.now() - 16 * 60_000;
  if (gapEndMs <= gapStartMs) return; // no gap

  const gapMins = Math.round((gapEndMs - gapStartMs) / 60_000);
  if (gapMins < 2) return;

  safeLog(`Gap fill for ${friendly}: ${gapMins} min gap starting ${new Date(gapStartMs).toISOString()}`);
  const filled = await fetchHistoricalBars(rawSym, "ohlcv-1m", new Date(gapStartMs).toISOString(), new Date(gapEndMs).toISOString());
  if (filled.length > 0) {
    const tagged = filled.map(b => ({ ...b, bar_source: "historical_gap_fill" }));
    bars1m[friendly] = [...(bars1m[friendly] || []), ...tagged].slice(-MAX_1M_BARS);
    gapFillLog.unshift({ friendly, gapMins, barsAdded: filled.length, at: new Date().toISOString() });
    if (gapFillLog.length > 20) gapFillLog.length = 20;
    safeLog(`Gap fill complete: ${filled.length} bars added for ${friendly}`);
  }
}

// ── Session reset ──────────────────────────────────────────────────────────────
let lastSessionDate = null;
function maybeResetSession() {
  const now    = new Date();
  const etHour = (now.getUTCHours() - 4 + 24) % 24;
  const today  = now.toISOString().slice(0, 10);
  if (lastSessionDate !== today && etHour >= 18) {
    lastSessionDate = today;
    Object.keys(sessionOHLCV).forEach(k => delete sessionOHLCV[k]);
    Object.keys(priceCache).forEach(k => delete priceCache[k]);
    // Reset forming bars at daily break — completed bars are kept for HTF context
    Object.keys(forming1m).forEach(k => delete forming1m[k]);
    Object.keys(forming5m).forEach(k => delete forming5m[k]);
    Object.keys(forming15m).forEach(k => delete forming15m[k]);
    Object.keys(seedState).forEach(k => delete seedState[k]); // allow re-seeding next session
    safeLog("Session reset: price cache, forming bars, and seed state cleared for new trading day");
  }
}

// ── State ──────────────────────────────────────────────────────────────────────
let connectionState    = "disconnected";
let binaryMode         = false;
let socket             = null;
let reconnectTimer     = null;
let reconnectDelay     = 2000;
let reconnectCount     = 0;
let lastConnectAt      = null;
let lastTickAt         = null;
let authSuccess        = false;
let totalTicksReceived = 0;
let lastAuthError      = null;
const startTime        = Date.now();

// ── Logging ────────────────────────────────────────────────────────────────────
function log(level, msg, ...args) {
  const ts   = new Date().toISOString();
  const safe = args.map(a => typeof a === "string" ? a.replace(API_KEY || "NOKEY", "***") : a);
  console[level](`[${ts}] [${level.toUpperCase()}] ${msg}`, ...safe);
}
function safeLog(msg, ...args) { log("log",   msg, ...args); }
function warnLog(msg, ...args) { log("warn",  msg, ...args); }
function errLog (msg, ...args) { log("error", msg, ...args); }

// ── CRAM Auth ──────────────────────────────────────────────────────────────────
function computeCramResponse(apiKey, challenge) {
  return crypto.createHmac("sha256", apiKey).update(challenge).digest("hex");
}

// ── DBN constants ──────────────────────────────────────────────────────────────
const RTYPE_TRADE          = 0;
const RTYPE_TRADE_ALT      = 48;
const RTYPE_INSTRUMENT_DEF = 19;
const RTYPE_SYM_MAP_MSG    = 90;
const RTYPE_SYSTEM_MSG     = 83;
const RTYPE_ERROR_MSG      = 21;

// ── DBN metadata header parser ─────────────────────────────────────────────────
let parseBuffer     = Buffer.alloc(0);
let dbnMetaConsumed = false;

function tryConsumeDbnMeta(buf) {
  if (buf.length < 8) return 0;
  if (buf[0] !== 0x44 || buf[1] !== 0x42 || buf[2] !== 0x4e) { dbnMetaConsumed = true; return 0; }
  const metaBodyLen = buf.readUInt32LE(4);
  const totalMeta   = 8 + metaBodyLen;
  if (buf.length < totalMeta) return 0;
  safeLog(`DBN metadata: version=${buf[3]}, body_length=${metaBodyLen}`);
  dbnMetaConsumed = true;
  return totalMeta;
}

// ── Symbol extraction ──────────────────────────────────────────────────────────
function extractSymbolFromText(text) {
  const patterns = [
    /\b(NQ\.c\.\d+)\b/, /\b(ES\.c\.\d+)\b/, /\b(MNQ\.c\.\d+)\b/, /\b(MES\.c\.\d+)\b/,
    /\b(NQ[FGHJKMNQUVXZ]\d+)\b/, /\b(ES[FGHJKMNQUVXZ]\d+)\b/,
    /\b(MNQ[FGHJKMNQUVXZ]\d+)\b/, /\b(MES[FGHJKMNQUVXZ]\d+)\b/,
  ];
  for (const p of patterns) { const m = text.match(p); if (m) return m[1]; }
  return null;
}

function registerInstrument(instrumentId, rawSym) {
  const friendly = toFriendly(rawSym);
  if (!friendly) return;
  if (instrumentIdMap[instrumentId] === friendly) return;
  instrumentIdMap[instrumentId] = friendly;
  safeLog(`Instrument mapped: id=${instrumentId} → "${rawSym}" → "${friendly}"`);
  const pending = pendingTrades[instrumentId];
  if (pending?.length > 0) {
    safeLog(`Flushing ${pending.length} pending trade(s) for id=${instrumentId} (${friendly})`);
    for (const t of pending) updateCache(friendly, t.price, t.tsEventMs, t.size);
    delete pendingTrades[instrumentId];
  }
}

// ── DBN binary record parser ───────────────────────────────────────────────────
function parseDbnRecord(buf) {
  if (buf.length < 2) return { consumed: 0 };
  const lengthWords = buf.readUInt8(0);
  const recordBytes = lengthWords * 4;
  if (recordBytes < 16) return { consumed: Math.max(recordBytes, 1) };
  if (buf.length < recordBytes) return { consumed: 0 };

  const rtype        = buf.readUInt8(1);
  const instrumentId = buf.readUInt32LE(4);
  const tsEventNs    = buf.readBigUInt64LE(8);
  const tsEventMs    = Number(tsEventNs / 1_000_000n);

  if (rtype === RTYPE_TRADE || rtype === RTYPE_TRADE_ALT) {
    if (recordBytes >= 32) {
      const priceRaw = buf.readBigInt64LE(16);
      const price    = Number(priceRaw) / 1e9;
      // size field at offset 24 (4 bytes, uint32)
      const size = recordBytes >= 28 ? buf.readUInt32LE(24) : 1;
      if (price > 100) {
        const friendly = instrumentIdMap[instrumentId];
        if (friendly) {
          updateCache(friendly, price, tsEventMs, size);
        } else {
          if (!pendingTrades[instrumentId]) pendingTrades[instrumentId] = [];
          pendingTrades[instrumentId].push({ price, tsEventMs, size });
        }
      }
    }
  } else if (rtype === RTYPE_INSTRUMENT_DEF) {
    if (recordBytes > 16) {
      const body   = buf.slice(16, recordBytes);
      const rawSym = extractSymbolFromText(body.toString("ascii"));
      if (rawSym) registerInstrument(instrumentId, rawSym);
    }
  } else if (rtype === RTYPE_SYM_MAP_MSG) {
    if (recordBytes >= 42) {
      const symBuf = buf.slice(22, Math.min(recordBytes, 22 + 24));
      const rawSym = symBuf.toString("ascii").replace(/\0/g, "").trim();
      if (rawSym) registerInstrument(instrumentId, rawSym);
    }
  } else if (rtype === RTYPE_SYSTEM_MSG || rtype === RTYPE_ERROR_MSG) {
    if (recordBytes > 16) {
      const msg = buf.slice(16, recordBytes).toString("utf8").replace(/\0/g, "").trim();
      if (msg) {
        if (rtype === RTYPE_ERROR_MSG) errLog(`Databento error: ${msg}`);
        else safeLog(`Databento system: ${msg}`);
      }
    }
  }

  return { consumed: recordBytes };
}

// ── Price cache + rolling bar updater ─────────────────────────────────────────
function updateCache(friendly, price, tsEventMs, size) {
  const now      = Date.now();
  const ageMs    = tsEventMs ? now - tsEventMs : 0;
  const ageS     = ageMs / 1000;
  const tsIso    = tsEventMs ? new Date(tsEventMs).toISOString() : new Date().toISOString();
  const contract = Object.keys(SYMBOL_ALIASES).find(k => SYMBOL_ALIASES[k] === friendly) || null;

  maybeResetSession();

  // Session OHLCV (for /snapshot)
  if (!sessionOHLCV[friendly]) {
    sessionOHLCV[friendly] = { open: price, high: price, low: price, vwap: price, tickCount: 0 };
  }
  const ohlcv = sessionOHLCV[friendly];
  if (price > ohlcv.high) ohlcv.high = price;
  if (price < ohlcv.low)  ohlcv.low  = price;
  ohlcv.tickCount++;
  ohlcv.vwap = (ohlcv.vwap * (ohlcv.tickCount - 1) + price) / ohlcv.tickCount;
  const pctChange = ohlcv.open > 0 ? ((price - ohlcv.open) / ohlcv.open * 100) : 0;

  priceCache[friendly] = {
    symbol: friendly, contract, price,
    open: ohlcv.open, high: ohlcv.high, low: ohlcv.low,
    vwap:            parseFloat(ohlcv.vwap.toFixed(2)),
    pct_change:      parseFloat(pctChange.toFixed(3)),
    timestamp:       tsIso,
    raw_ts_event_ms: tsEventMs,
    age_seconds:     parseFloat(ageS.toFixed(3)),
    is_live_feed:    true,
    _receivedAt:     now,
  };

  // Rolling OHLCV bars
  updateRollingBars(friendly, price, tsEventMs || now, size);

  // Seed on first tick if not already seeded
  if (!seedState[friendly]?.seeded) {
    seedSymbol(friendly).catch(e => warnLog(`Seed error ${friendly}: ${e.message}`));
  }

  lastTickAt = now;
  totalTicksReceived++;
  if (totalTicksReceived <= 5 || totalTicksReceived % 100 === 0) {
    safeLog(`Tick #${totalTicksReceived}: ${friendly} @ ${price} (age ${ageS.toFixed(1)}s)`);
  }
  resetWatchdog();
}

// ── Watchdog ───────────────────────────────────────────────────────────────────
function watchdogMs() {
  const h = (new Date().getUTCHours() - 4 + 24) % 24;
  return (h >= 9 && h < 16) ? 30_000 : 120_000;
}
let watchdogTimer = null;
function resetWatchdog() {
  if (watchdogTimer) clearTimeout(watchdogTimer);
  watchdogTimer = setTimeout(() => {
    if (connectionState === "streaming" || connectionState === "subscribed") {
      const ageS = lastTickAt ? ((Date.now() - lastTickAt) / 1000).toFixed(1) : "never";
      warnLog(`Watchdog: no tick in ${ageS}s — forcing reconnect`);
      if (socket) socket.destroy();
    }
  }, watchdogMs());
}

// ── TCP connection ─────────────────────────────────────────────────────────────
let textLineBuffer = "";

function connect() {
  if (socket) { try { socket.destroy(); } catch (_) {} socket = null; }
  if (!API_KEY) { errLog("DATABENTO_API_KEY not set"); connectionState = "error_no_key"; return; }

  connectionState  = "connecting";
  binaryMode       = false;
  lastConnectAt    = Date.now();
  authSuccess      = false;
  dbnMetaConsumed  = false;
  parseBuffer      = Buffer.alloc(0);
  textLineBuffer   = "";
  lastAuthError    = null;
  Object.keys(instrumentIdMap).forEach(k => delete instrumentIdMap[k]);
  Object.keys(pendingTrades).forEach(k => delete pendingTrades[k]);

  safeLog(`Connecting to ${GATEWAY_HOST}:${GATEWAY_PORT} (attempt #${reconnectCount + 1})`);

  socket = net.createConnection({ host: GATEWAY_HOST, port: GATEWAY_PORT });
  socket.setTimeout(60_000);

  socket.on("connect", () => { safeLog("TCP connected"); connectionState = "authenticating"; reconnectDelay = 2_000; });

  socket.on("data", (chunk) => {
    if (!binaryMode) handleTextData(chunk);
    else handleBinaryData(chunk);
  });

  socket.on("close", (hadError) => {
    safeLog(`Connection closed${hadError ? " (with error)" : ""}`);
    connectionState = "disconnected";
    binaryMode = false; socket = null;
    if (watchdogTimer) { clearTimeout(watchdogTimer); watchdogTimer = null; }
    scheduleReconnect();
  });

  socket.on("error", (err) => {
    errLog(`Socket error: ${err.code || err.message}`);
    connectionState = "error"; binaryMode = false; socket = null;
    if (watchdogTimer) { clearTimeout(watchdogTimer); watchdogTimer = null; }
    scheduleReconnect();
  });

  socket.on("timeout", () => { warnLog("Socket timeout"); socket.destroy(); });
}

function handleTextData(chunk) {
  textLineBuffer += chunk.toString("utf8");
  const lines = textLineBuffer.split("\n");
  textLineBuffer = lines.pop();

  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) continue;

    const fields = {};
    for (const part of line.split("|")) {
      const eq = part.indexOf("=");
      if (eq !== -1) fields[part.slice(0, eq)] = part.slice(eq + 1);
    }

    if (fields.cram) {
      const hmacHex = computeCramResponse(API_KEY, fields.cram);
      const authMsg = [
        `auth=${hmacHex}`, `dataset=${DATASET}`, `encoding=dbn`,
        `schema=${SCHEMA}`, `stype_in=continuous`, `symbols=${RAW_SYMBOLS}`,
      ].join("|") + "\n";
      safeLog("CRAM challenge — sending HMAC auth");
      socket.write(authMsg, "utf8");
      return;
    }

    if (fields.success === "1") {
      authSuccess = true; reconnectCount = 0;
      connectionState = "subscribed";
      safeLog(`Auth OK — session_id=${fields.session_id || "?"}`);
      socket.write("start_session\n", "utf8");
      connectionState = "streaming";
      binaryMode = true;
      if (textLineBuffer.length > 0) {
        const leftover = Buffer.from(textLineBuffer, "utf8");
        textLineBuffer = "";
        handleBinaryData(leftover);
      }
      resetWatchdog();
      // Trigger gap fill for all symbols after reconnect
      const friendlies = [...new Set(RAW_SYMBOLS.split(",").map(s => toFriendly(s.trim())).filter(Boolean))];
      for (const f of friendlies) {
        gapFillSymbol(f).catch(e => warnLog(`Gap fill error ${f}: ${e.message}`));
      }
      return;
    }

    if (fields.error || fields.success === "0") {
      lastAuthError = fields.error || "unknown";
      errLog(`Auth failed: ${lastAuthError}`);
      connectionState = "auth_failed";
      socket.destroy();
      return;
    }
  }
}

function handleBinaryData(chunk) {
  parseBuffer = Buffer.concat([parseBuffer, chunk]);
  if (!dbnMetaConsumed) {
    const consumed = tryConsumeDbnMeta(parseBuffer);
    if (consumed === 0 && !dbnMetaConsumed) return;
    if (consumed > 0) parseBuffer = parseBuffer.slice(consumed);
  }
  while (parseBuffer.length >= 2) {
    const { consumed } = parseDbnRecord(parseBuffer);
    if (consumed === 0) break;
    parseBuffer = parseBuffer.slice(consumed);
  }
}

function scheduleReconnect() {
  if (reconnectTimer) clearTimeout(reconnectTimer);
  reconnectCount++;
  const delay = Math.min(reconnectDelay, 60_000);
  reconnectDelay = Math.min(reconnectDelay * 2, 60_000);
  safeLog(`Reconnect in ${delay}ms (attempt #${reconnectCount + 1})`);
  reconnectTimer = setTimeout(connect, delay);
}

// ── Bar health helper ──────────────────────────────────────────────────────────
function barCacheHealth(friendly) {
  const arr1m  = bars1m[friendly]  || [];
  const arr5m  = bars5m[friendly]  || [];
  const arr15m = bars15m[friendly] || [];
  const f1m    = forming1m[friendly];
  const f5m    = forming5m[friendly];
  const now    = Date.now();

  const last1m  = arr1m.at(-1);
  const last5m  = arr5m.at(-1);
  const last15m = arr15m.at(-1);

  const last1mAgeS  = last1m?.ts  ? (now - last1m.ts)  / 1000 : null;
  const last5mAgeS  = last5m?.ts  ? (now - last5m.ts)  / 1000 : null;

  // Determine if proxy bars are healthy enough for the scanner to use them
  // vs needing to fall back to historical REST
  const healthy = arr1m.length >= 20 && last1mAgeS !== null && last1mAgeS < 300; // last 1m bar < 5 min old

  // Count bars by source
  const countBySource = (arr) => arr.reduce((acc, b) => {
    const s = b.bar_source || "unknown";
    acc[s] = (acc[s] || 0) + 1;
    return acc;
  }, {});

  return {
    healthy,
    bars_1m:  arr1m.length,
    bars_5m:  arr5m.length,
    bars_15m: arr15m.length,
    forming_1m:  f1m  ? { open: f1m.open,  high: f1m.high,  low: f1m.low,  close: f1m.close,  volume: f1m.volume,  ts_iso: f1m.ts_iso,  bar_source: f1m.bar_source  } : null,
    forming_5m:  f5m  ? { open: f5m.open,  high: f5m.high,  low: f5m.low,  close: f5m.close,  volume: f5m.volume,  ts_iso: f5m.ts_iso,  bar_source: f5m.bar_source  } : null,
    last_1m_ts:    last1m?.ts_iso  || null,
    last_5m_ts:    last5m?.ts_iso  || null,
    last_15m_ts:   last15m?.ts_iso || null,
    last_1m_age_s: last1mAgeS  != null ? Math.round(last1mAgeS)  : null,
    last_5m_age_s: last5mAgeS  != null ? Math.round(last5mAgeS)  : null,
    seeded:   seedState[friendly]?.seeded || false,
    seed_count_1m:  seedState[friendly]?.seedCount1m || 0,
    sources_1m: countBySource(arr1m),
    sources_5m: countBySource(arr5m),
  };
}

// ── Express HTTP server ────────────────────────────────────────────────────────
const app = express();
app.use(cors());
app.use(express.json());

// Existing /health endpoint (unchanged for backwards compat)
app.get("/health", (req, res) => {
  const connected    = connectionState === "streaming" || connectionState === "subscribed";
  const lastTickAgeS = lastTickAt ? parseFloat(((Date.now() - lastTickAt) / 1000).toFixed(1)) : null;
  const uptimeS      = Math.round((Date.now() - startTime) / 1000);
  const friendlies   = [...new Set(RAW_SYMBOLS.split(",").map(s => toFriendly(s.trim())).filter(Boolean))];

  res.json({
    status:                  connected ? "ok" : "degraded",
    provider:                "Databento",
    connection_state:        connectionState,
    binary_mode:             binaryMode,
    connected,
    is_live_feed:            connected,
    feed_type:               "live_proxy",
    dataset:                 DATASET,
    schema:                  SCHEMA,
    gateway:                 `${GATEWAY_HOST}:${GATEWAY_PORT}`,
    symbols_subscribed:      RAW_SYMBOLS.split(",").map(s => s.trim()),
    symbols_with_data:       Object.keys(priceCache),
    instrument_ids_mapped:   Object.keys(instrumentIdMap).length,
    instrument_map:          instrumentIdMap,
    pending_unmapped_trades: Object.keys(pendingTrades).reduce((s, k) => s + (pendingTrades[k]?.length || 0), 0),
    auth_success:            authSuccess,
    last_auth_error:         lastAuthError,
    last_update:             lastTickAt ? new Date(lastTickAt).toISOString() : null,
    last_tick_age_seconds:   lastTickAgeS,
    total_ticks:             totalTicksReceived,
    uptime_seconds:          uptimeS,
    reconnect_count:         reconnectCount,
    last_connect_at:         lastConnectAt ? new Date(lastConnectAt).toISOString() : null,
    rolling_bars:            Object.fromEntries(friendlies.map(f => [f, barCacheHealth(f)])),
  });
});

// Existing /snapshot endpoint (unchanged for backwards compat)
app.get("/snapshot", (req, res) => {
  const now         = Date.now();
  const isConnected = connectionState === "streaming" || connectionState === "subscribed";
  const uptimeS     = Math.round((now - startTime) / 1000);
  const symbolsOut  = {};

  for (const raw of RAW_SYMBOLS.split(",")) {
    const friendly = toFriendly(raw.trim());
    if (!friendly) continue;
    const cached   = priceCache[friendly];

    if (!cached) {
      const noDataStatus = !isConnected ? "disconnected" : !authSuccess ? "auth_failed"
        : uptimeS > 120 ? "stream_frozen" : "no_data_yet";
      symbolsOut[friendly] = {
        symbol: friendly, price: null, timestamp: null, age_seconds: null,
        is_live_feed: false, provider: "Databento", status: noDataStatus,
        error: !isConnected ? `Feed disconnected (state: ${connectionState})`
          : !authSuccess ? `Auth failed: ${lastAuthError || "unknown"}`
          : uptimeS > 120 ? `Stream frozen: connected ${uptimeS}s ago, 0 ticks.`
          : `Awaiting first tick (connected ${uptimeS}s ago)`,
      };
      continue;
    }

    const ageS    = parseFloat(((now - cached._receivedAt) / 1000).toFixed(3));
    const isStale = ageS > STALE_THRESHOLD_S;

    symbolsOut[friendly] = {
      symbol: cached.symbol, contract: cached.contract, price: cached.price,
      open: cached.open, high: cached.high, low: cached.low, vwap: cached.vwap,
      pct_change: cached.pct_change, timestamp: cached.timestamp,
      age_seconds: ageS, raw_ts_event_ms: cached.raw_ts_event_ms,
      is_live_feed: !isStale, provider: "Databento",
      status: isStale ? "stale" : "live",
      ...(isStale ? { error: `Last tick ${ageS.toFixed(1)}s ago` } : {}),
    };
  }

  res.json({
    provider: "Databento", feed_type: "live_proxy",
    is_live_feed: isConnected && Object.values(symbolsOut).some(s => s.is_live_feed),
    connection_state: connectionState, binary_mode: binaryMode, auth_success: authSuccess,
    instrument_ids_mapped: Object.keys(instrumentIdMap).length,
    pending_unmapped: Object.keys(pendingTrades).reduce((s, k) => s + (pendingTrades[k]?.length || 0), 0),
    total_ticks: totalTicksReceived,
    last_tick_at: lastTickAt ? new Date(lastTickAt).toISOString() : null,
    uptime_seconds: uptimeS, server_time: new Date().toISOString(),
    symbols: symbolsOut,
    status: {
      live_client_started: authSuccess,
      last_record_at: lastTickAt ? new Date(lastTickAt).toISOString() : null,
      record_count: totalTicksReceived, connection_state: connectionState, error: lastAuthError || null,
    },
  });
});

// ── NEW: /bars/1m ──────────────────────────────────────────────────────────────
app.get("/bars/1m", (req, res) => {
  const sym  = (req.query.symbol || "").toUpperCase();
  const n    = Math.min(parseInt(req.query.n || "100", 10), MAX_1M_BARS);
  const syms = sym ? [sym] : [...new Set(RAW_SYMBOLS.split(",").map(s => toFriendly(s.trim())).filter(Boolean))];
  const out  = {};

  for (const s of syms) {
    const arr  = bars1m[s] || [];
    const last = arr.slice(-n);
    const health = barCacheHealth(s);
    out[s] = {
      bars:          last,
      forming_bar:   forming1m[s] || null,
      total_cached:  arr.length,
      returned:      last.length,
      healthy:       health.healthy,
      last_bar_ts:   health.last_1m_ts,
      last_bar_age_s:health.last_1m_age_s,
      seeded:        health.seeded,
      sources:       health.sources_1m,
      bar_source_primary: arr.length > 0 ? (arr.filter(b => b.bar_source === "proxy_live").length > arr.length * 0.5 ? "proxy_live" : "historical_seed") : "none",
    };
  }

  res.json({
    interval: "1m",
    connection_state: connectionState,
    total_ticks: totalTicksReceived,
    server_time: new Date().toISOString(),
    symbols: out,
  });
});

// ── NEW: /bars/5m ──────────────────────────────────────────────────────────────
app.get("/bars/5m", (req, res) => {
  const sym  = (req.query.symbol || "").toUpperCase();
  const n    = Math.min(parseInt(req.query.n || "300", 10), MAX_5M_BARS);
  const syms = sym ? [sym] : [...new Set(RAW_SYMBOLS.split(",").map(s => toFriendly(s.trim())).filter(Boolean))];
  const out  = {};

  for (const s of syms) {
    const arr  = bars5m[s] || [];
    const last = arr.slice(-n);
    const health = barCacheHealth(s);
    out[s] = {
      bars:          last,
      forming_bar:   forming5m[s] || null,
      total_cached:  arr.length,
      returned:      last.length,
      healthy:       health.healthy,
      last_bar_ts:   health.last_5m_ts,
      last_bar_age_s:health.last_5m_age_s,
      seeded:        health.seeded,
      sources:       health.sources_5m,
    };
  }

  res.json({
    interval: "5m",
    connection_state: connectionState,
    total_ticks: totalTicksReceived,
    server_time: new Date().toISOString(),
    symbols: out,
  });
});

// ── NEW: /bars/15m ─────────────────────────────────────────────────────────────
app.get("/bars/15m", (req, res) => {
  const sym  = (req.query.symbol || "").toUpperCase();
  const n    = Math.min(parseInt(req.query.n || "200", 10), MAX_15M_BARS);
  const syms = sym ? [sym] : [...new Set(RAW_SYMBOLS.split(",").map(s => toFriendly(s.trim())).filter(Boolean))];
  const out  = {};

  for (const s of syms) {
    const arr  = bars15m[s] || [];
    const last = arr.slice(-n);
    out[s] = {
      bars:         last,
      forming_bar:  forming15m[s] || null,
      total_cached: arr.length,
      returned:     last.length,
      healthy:      barCacheHealth(s).healthy,
      last_bar_ts:  arr.at(-1)?.ts_iso || null,
    };
  }

  res.json({ interval: "15m", connection_state: connectionState, server_time: new Date().toISOString(), symbols: out });
});

// ── NEW: /bars/status ──────────────────────────────────────────────────────────
app.get("/bars/status", (req, res) => {
  const now       = Date.now();
  const friendlies = [...new Set(RAW_SYMBOLS.split(",").map(s => toFriendly(s.trim())).filter(Boolean))];
  const connected  = connectionState === "streaming" || connectionState === "subscribed";

  const perSymbol = {};
  for (const f of friendlies) {
    perSymbol[f] = barCacheHealth(f);
  }

  const allHealthy = friendlies.every(f => perSymbol[f].healthy);

  res.json({
    websocket_connected:   connected,
    connection_state:      connectionState,
    auth_success:          authSuccess,
    total_ticks:           totalTicksReceived,
    last_tick_at:          lastTickAt ? new Date(lastTickAt).toISOString() : null,
    last_tick_age_s:       lastTickAt ? Math.round((now - lastTickAt) / 1000) : null,
    all_symbols_healthy:   allHealthy,
    historical_fallback_recommended: !allHealthy,
    gap_fill_log:          gapFillLog.slice(0, 5),
    per_symbol:            perSymbol,
    server_time:           new Date().toISOString(),
    uptime_seconds:        Math.round((now - startTime) / 1000),
  });
});

// ── Startup ────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  safeLog(`EdgeOS Databento proxy v3 listening on port ${PORT}`);
  safeLog(`Dataset: ${DATASET} | Schema: ${SCHEMA} | Symbols: ${RAW_SYMBOLS}`);
  safeLog(`Gateway: ${GATEWAY_HOST}:${GATEWAY_PORT}`);
  safeLog(`Rolling bars: 1m=${MAX_1M_BARS} 5m=${MAX_5M_BARS} 15m=${MAX_15M_BARS}`);
  if (!API_KEY) {
    errLog("DATABENTO_API_KEY not set — proxy will not connect");
    connectionState = "error_no_key";
    return;
  }
  // Pre-seed all symbols at startup (before any ticks arrive)
  const friendlies = [...new Set(RAW_SYMBOLS.split(",").map(s => toFriendly(s.trim())).filter(Boolean))];
  for (const f of friendlies) {
    seedSymbol(f).catch(e => warnLog(`Startup seed error ${f}: ${e.message}`));
  }
  connect();
});

process.on("SIGTERM", () => {
  safeLog("SIGTERM — shutting down");
  if (reconnectTimer) clearTimeout(reconnectTimer);
  if (watchdogTimer) clearTimeout(watchdogTimer);
  if (socket) socket.destroy();
  process.exit(0);
});

process.on("SIGINT", () => {
  safeLog("SIGINT — shutting down");
  if (reconnectTimer) clearTimeout(reconnectTimer);
  if (watchdogTimer) clearTimeout(watchdogTimer);
  if (socket) socket.destroy();
  process.exit(0);
});
